import streamlit as st
from transformers import pipeline


# ------------------------------
# Load Whisper Model
# ------------------------------
def load_whisper_model():
    """
    Load the Whisper model for audio transcription.
    """
    try:
        # Load the Whisper pipeline for speech recognition
        whisper_model = pipeline(task="automatic-speech-recognition", model="openai/whisper-tiny",chunk_length_s=30)
        return whisper_model
    except Exception as e:
        # Display an error message
        st.error(f"Error in loading Whisper model: {e}")
        return None


# ------------------------------
# Load NER Model
# ------------------------------
def load_ner_model():
    """
    Load the Named Entity Recognition (NER) model pipeline.
    """
    try:
        # Load the NER pipeline for extracting entities from text
        ner_model = pipeline(task="ner", model="dslim/bert-base-NER", aggregation_strategy="simple")
        return ner_model
    except Exception as e:
        # Display an error message
        st.error(f"Error in loading NER model: {e}")
        return None


# ------------------------------
# Transcription Logic
# ------------------------------
def transcribe_audio(uploaded_file, whisper_model):
    """
    Transcribe audio into text using the Whisper model.
    Args:
        uploaded_file: Audio file uploaded by the user.
        whisper_model: Loaded Whisper model pipeline.
    Returns:
        str: Transcribed text from the audio file.
    """
    try:
        # Read the audio file content
        audio_data = uploaded_file.read()
        # Perform transcription using the Whisper model
        transcription_result = whisper_model(audio_data)
        return transcription_result.get("text")
    except Exception as e:
        # Display an error message
        st.error(f"Error in transcribing audio: {e}")
        return ""


# ------------------------------
# Entity Extraction
# ------------------------------
def extract_entities(text, ner_pipeline):
    """
    Extract entities from transcribed text using the NER model.
    Args:
        text (str): Transcribed text.
        ner_pipeline: NER pipeline loaded from Hugging Face.
    Returns:
        dict: Grouped entities (ORGs, LOCs, PERs).
    """
    # Initialize a dictionary for grouping entities
    grouped_entities = dict()
    grouped_entities["Organizations"] = list()
    grouped_entities["Locations"] = list()
    grouped_entities["Persons"] = list()

    try:
        # Extract entities from the text using the NER model
        extracted_entities = ner_pipeline(text)
        for entity in extracted_entities:
            # Group entities and remove duplicates
            if (entity["entity_group"] == "PER") and (entity["word"] not in grouped_entities["Persons"]):
                grouped_entities["Persons"].append(entity["word"])
            elif (entity["entity_group"] == "ORG") and (entity["word"] not in grouped_entities["Organizations"]):
                grouped_entities["Organizations"].append(entity["word"])
            elif (entity["entity_group"] == "LOC") and (entity["word"] not in grouped_entities["Locations"]):
                grouped_entities["Locations"].append(entity["word"])

        return grouped_entities
    except Exception as e:
        # Display an error message
        st.error(f"Error in extracting entities: {e}")
        return grouped_entities


# ------------------------------
# Main Streamlit Application
# ------------------------------
def main():
    # Title
    st.title("Meeting Transcription and Entity Extraction")

    # Student Information
    STUDENT_NAME = "İbrahim BANCAR"
    STUDENT_ID = "150220313"
    st.markdown(f"**{STUDENT_ID} - {STUDENT_NAME}**")

    # Instructions
    st.markdown("""
    Upload a business meeting audio file to:
    1. Transcribe the meeting audio into text.
    2. Extract key entities such as Persons, Organizations, Dates, and Locations.
    """)

    # File upload section
    st.markdown("Upload an audio file (WAV format)")
    uploaded_file = st.file_uploader("", type="wav", label_visibility="collapsed")

    if uploaded_file:
        # Play the uploaded audio file
        st.audio(uploaded_file, format="audio/wav")

        # Load Whisper and NER models
        whisper_model = load_whisper_model()
        ner_model = load_ner_model()

        if whisper_model and ner_model:
            # Perform audio transcription
            with st.spinner("Transcribing the audio file... This may take a minute."):
                transcription = transcribe_audio(uploaded_file, whisper_model)
                if transcription:
                    st.markdown("### Transcription:")
                    st.write(transcription)  # Display the transcription
                else:
                    st.error("Failed to transcribe the audio file.")

            # Perform entity extraction and display them
            with st.spinner("Extracting entities..."):
                entities = extract_entities(transcription, ner_model)
            st.markdown("### Extracted Entities:")

            # Organizations
            st.markdown("#### Organizations (ORGs):")
            if entities["Organizations"]:
                st.write("\n".join(f"- {org}" for org in entities["Organizations"]))
            else:
                st.write("No organizations found.")

            # Locations
            st.markdown("#### Locations (LOCs):")
            if entities["Locations"]:
                st.write("\n".join(f"- {loc}" for loc in entities["Locations"]))
            else:
                st.write("No locations found.")

            # Persons
            st.markdown("#### Persons (PERs):")
            if entities["Persons"]:
                st.write("\n".join(f"- {person}" for person in entities["Persons"]))
            else:
                st.write("No persons found.")
        else:
            # Display an error
            st.error("Failed to load the required models. Please try again.")


if __name__ == "__main__":
    main()